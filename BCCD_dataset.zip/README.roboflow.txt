
BCCD - v1 BCCD_test
==============================

This dataset was exported via roboflow.ai on February 23, 2022 at 7:25 AM GMT

It includes 364 images.
Cells are annotated in YOLO v5 PyTorch format.

The following pre-processing was applied to each image:
* Resize to 416x416 (Stretch)

The following augmentation was applied to create 1 versions of each source image:
* 50% probability of horizontal flip
* 50% probability of vertical flip
* Equal probability of one of the following 90-degree rotations: none, clockwise, counter-clockwise, upside-down
* Randomly crop between 0 and 15 percent of the image
* Random brigthness adjustment of between -15 and +15 percent
* Random exposure adjustment of between -20 and +20 percent


